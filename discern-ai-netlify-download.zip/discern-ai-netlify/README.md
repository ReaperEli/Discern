# Discern AI — Netlify + OpenAI

Discern AI is a responsive Christian routine and Scripture companion. It uses an OpenAI model through a Netlify Function so the API key is kept server-side.

## Deploy to Netlify

1. Extract the ZIP.
2. Push the extracted project folder to a GitHub repository. The `netlify.toml` file and `netlify/functions/discern.js` function must be included.
3. In Netlify, choose **Add new site → Import an existing project** and connect that GitHub repository. This deploy method is required so Netlify builds and deploys the serverless function; a simple static drag-and-drop deploy will not publish the function.
4. In the Netlify site, open **Project configuration → Environment variables**.
5. Add `OPENAI_API_KEY` and paste your OpenAI API key as its value. Set the variable scope to **Functions** (or all scopes if Netlify's interface requires it). Do not put the key in `index.html`, a public `.env` file, or client-side JavaScript.
6. Trigger a fresh deploy after adding or changing the variable.

The included function is `netlify/functions/discern.js`. The browser calls `/.netlify/functions/discern` for AI routine generation and assistant responses. It uses the `gpt-4.1-mini` model via the OpenAI Responses API. API usage is billed separately from ChatGPT subscriptions.

## Features

- AI-generated, personalized **morning**, **daytime**, and **night** routines based on the user's schedule, school/work hours, commute, shower preference, exercise, homework, interests, and faith preferences.
- Detailed checklist items, completion tracking, progress, and reset controls.
- AI Christian assistant that answers open-ended questions and includes a relevant Bible reference with context-aware guidance.
- Devotionals, Bible study outlines, prayer planner, goals, local data export/import, and privacy controls.
- Responsive dark navy and gold interface.

## Local development

The static page can be opened directly, but AI calls require Netlify Functions. Install the Netlify CLI and run `netlify dev` from this project directory after setting `OPENAI_API_KEY` in your local environment. Never commit a real API key. You can also connect the project to a Git repository as described above.

## Privacy and limitations

Routine answers and questions sent to the AI features are processed by the Netlify Function and sent to OpenAI to generate responses. The API key stays in Netlify's environment and is not exposed to visitors. Other saved data (routine checklist status, prayer notes, goals, profile, and chat history) is stored in the visitor's browser local storage. Avoid entering highly sensitive information. Review OpenAI's current API data controls and terms before launch.

AI-generated routines and Bible explanations can be inaccurate. Users should review schedule suggestions, verify Scripture references and read passages in context, and seek trusted human guidance for important spiritual, health, or safety matters. Discern does not claim to speak for God or replace a pastor or professional.

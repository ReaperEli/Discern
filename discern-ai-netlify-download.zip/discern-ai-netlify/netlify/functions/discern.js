const OPENAI_URL = 'https://api.openai.com/v1/responses';
const MODEL = 'gpt-4.1-mini';

function json(statusCode, body) {
  return { statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify(body) };
}

function outputText(response) {
  if (typeof response.output_text === 'string') return response.output_text;
  const chunks = [];
  for (const item of response.output || []) {
    for (const content of item.content || []) if (content.type === 'output_text' && content.text) chunks.push(content.text);
  }
  return chunks.join('\n').trim();
}

async function askOpenAI(instructions, input, maxOutputTokens = 1800) {
  if (!process.env.OPENAI_API_KEY) throw new Error('OPENAI_API_KEY is not configured in Netlify environment variables.');
  const response = await fetch(OPENAI_URL, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: MODEL, instructions, input, max_output_tokens: maxOutputTokens })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = data.error?.message || `AI provider returned HTTP ${response.status}.`;
    throw new Error(message.slice(0, 500));
  }
  const text = outputText(data);
  if (!text) throw new Error('The AI returned an empty response. Please try again.');
  return text;
}

function parseJson(text) {
  const cleaned = text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
  return JSON.parse(cleaned);
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: { 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'POST' } };
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed.' });
  let body;
  try { body = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Invalid request body.' }); }

  try {
    if (body.action === 'routine') {
      const a = body.answers || {};
      const instructions = `You are Discern AI, a practical Christian daily-routine planner. Create a highly detailed but organized realistic daily schedule from the user's answers. Return ONLY valid JSON with this exact shape: {"summary":"one short personalized sentence","morning":[{"time":"6:00 AM","title":"...","detail":"2-4 clear sentences with practical steps","duration":10}],"daytime":[...],"night":[...]}. Each section must be an array of objects with time, title, detail, duration. Use clear 12-hour clock times. Make the morning routine and night routine especially complete and useful: waking up, making bed, bathroom, brushing/flossing as appropriate, face care, shower according to preference, hair/personal care, getting dressed, breakfast, Bible reading/devotional, prayer and worship if requested, preparation/packing; at night include prepare tomorrow, shower if preferred, evening hygiene, quiet reflection/prayer, screens-down wind-down, bedtime. Do not force every hygiene item into both sections if it would be repetitive or impractical. Daytime must respect fixed school/work hours, commute, meals, breaks, activities, homework, chores/family commitments, and rest. Do not schedule over fixed commitments. Include realistic transition buffers. Do not invent school/work times or activities that conflict with answers. Fit everything between wake and bed; if time is tight, prioritize fixed responsibilities, sleep, meals, and essential care, then keep optional activities brief. Avoid medical claims, calorie/weight advice, or overly demanding exercise. Keep steps encouraging and non-judgmental. The Bible portion should suggest reading a passage reference rather than inventing a Bible quotation. Return 5-9 morning steps, 3-8 daytime steps, and 4-8 night steps where the available time allows. Do not include markdown fences or text outside the JSON.`;
      const raw = await askOpenAI(instructions, `Create the routine using these user answers. Treat these as user preferences and schedule facts:\n${JSON.stringify(a)}`, 2600);
      let plan;
      try { plan = parseJson(raw); } catch { throw new Error('The routine response was not valid structured data. Please regenerate.'); }
      for (const section of ['morning', 'daytime', 'night']) {
        if (!Array.isArray(plan[section])) plan[section] = [];
        plan[section] = plan[section].slice(0, 14).map(item => ({
          time: String(item.time || '').slice(0, 30), title: String(item.title || 'Routine step').slice(0, 90),
          detail: String(item.detail || '').slice(0, 600), duration: Math.max(0, Math.min(240, Number(item.duration) || 0))
        }));
      }
      return json(200, { plan: { summary: String(plan.summary || '').slice(0, 300), morning: plan.morning, daytime: plan.daytime, night: plan.night } });
    }

    if (body.action === 'chat') {
      const messages = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
      const transcript = messages.map(m => `${m.role === 'assistant' ? 'Discern' : 'User'}: ${String(m.content || '').slice(0, 1800)}`).join('\n\n');
      const translation = String(body.translation || 'ESV').slice(0, 20);
      const instructions = `You are Discern AI, a warm, thoughtful Christian study companion. Answer the user's actual question clearly and practically. Always include at least one relevant Bible verse reference (book, chapter, and verse) and explain briefly why it relates. Prefer the user's stated translation (${translation}) when naming a translation, but do not fabricate exact Bible quotations. Unless you are certain a quotation is public domain, provide the reference and summarize the passage in your own words instead of quoting it. Distinguish what the passage says from your interpretation. Respect that Christians may interpret some topics differently; acknowledge uncertainty when appropriate. Do not claim to speak for God, predict God's private will for the user, replace a pastor/counselor/doctor, or present yourself as a spiritual authority. For medical, mental-health, safety, abuse, or crisis questions, give careful supportive guidance and encourage help from a trusted adult or qualified professional where appropriate. Keep the tone respectful, non-judgmental, age-appropriate, and not preachy. End with a short practical next step or reflective question when useful.`;
      const answer = await askOpenAI(instructions, transcript || 'User: Hello, Discern.', 1200);
      return json(200, { answer });
    }
    return json(400, { error: 'Unknown action.' });
  } catch (error) {
    console.error('Discern function error:', error.message);
    const message = error.message.includes('OPENAI_API_KEY') ? error.message : `Discern AI could not complete that request. ${error.message}`;
    return json(500, { error: message.slice(0, 600) });
  }
};
